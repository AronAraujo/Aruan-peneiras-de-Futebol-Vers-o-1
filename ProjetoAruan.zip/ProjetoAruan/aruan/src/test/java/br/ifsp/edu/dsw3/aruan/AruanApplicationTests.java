package br.ifsp.edu.dsw3.aruan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AruanApplicationTests {

	@Test
	void contextLoads() {
	}

}
